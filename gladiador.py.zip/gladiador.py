print("Ejercicio 5 — “Escape Room: La Arena del Gladiador")

print("---------BIENVENIDO A LA ARENA---------")

gladiador = input("Nombre del Gladiador: ").strip()
                                                              
while gladiador == "" or not gladiador.isalpha():            #VALIDAR NOMBRE
    print("Error: Solo se permiten letras.")
    gladiador = input("Nombre del Gladiador: ").strip()


print("------------INICIO DEL COMBATE--------------")
                                                                     #Variables
vida_jugador = 100
vida_enemigo = 100
pociones = 3
daño_pesado = 15
daño_enemigo = 12
turno_jugador = True


while vida_jugador > 0 and vida_enemigo > 0:
                                                                                                    
                                                                                                     
                                                                                                            #VALIDACION MENU
    print(f"\n{gladiador} (HP: {vida_jugador}) vs Enemigo (HP: {vida_enemigo}) | Pociones: {pociones}")
    print("Elige acción:")
    print("1. Ataque Pesado")
    print("2. Ráfaga Veloz")
    print("3. Curar")

    opcion = input("Opción: ")

    
    while not opcion.isdigit() or int(opcion) not in (1, 2, 3):
        print("Error! Ingrese un número valido")
        opcion = input("Opción: ")
        opcion = int(opcion)

    
    if opcion == "1":
        if vida_enemigo < 20:
            daño = daño_pesado * 1.5
            print(" ¡Golpe critico!")
        else:
            daño = daño_pesado

        vida_enemigo -= daño
        print(f" ¡Atacaste al enemigo por {daño} puntos de daño!")

    
    elif opcion == "2":
        print("Inicias una rafaga de golpes!")
        for i in range(3):
            vida_enemigo -= 5
            print(" Golpe conectado por 5 de daño")

                                                                        #Opcion Curar
    elif opcion == "3":
        if pociones > 0:
            vida_jugador += 30
            pociones -= 1
            print("Te curaste 30 puntos de vida")
        else:
            print("¡No quedan pociones!")

      
    if vida_enemigo > 0:
        vida_jugador -= daño_enemigo
        print(f"El enemigo te atacO por {daño_enemigo} puntos de daño!")

                                                                                           # Resultado final
print("------------------FIN DEL JUEGO--------------------------")

if vida_jugador > 0:
    print(f"¡VICTORIA! {gladiador} ha ganado la batalla ")
else:
    print("DERROTA. Has caido en combate ")
 



   



  

