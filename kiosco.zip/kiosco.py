print("Ejercicio 1— “Caja del Kiosco”")

nombre = input("Ingrese nombre del cliente:  ").strip().upper()
  
while not nombre.isalpha():
   print("Error! ingrese solo letras ")
   nombre = input("Ingrese nombre del cliente:  ").strip()

cantidad = input("ingrese la cantidad de producto: ").strip()

while not cantidad.isdigit():
   print("ERROR , ingrese solo numeros positivos mayores a cero")
   cantidad = input("ingrese la cantidad de producto: ").strip()

cantidad = int(cantidad)
   
total_sin_descuento = 0
total_con_descuento = 0.0
for i in range(1,cantidad + 1):
        precio = input(f"producto {i} - precio :").strip()

        while not precio.isdigit():
           print("ERROR, el precio debe ser solo numeros positivos y mayor a cero")
           precio_int = input(f"producto {i} - precio :").strip()

        precio_int = int(precio)

        desc = input("Elija S si tiene descuento o  N si no tiene: ").strip().lower()

        while desc != "s" and desc != "n":
         print("Error! solo S o N")
         desc = input("Elija S si tiene descuento o  N si no tiene: ").strip().lower()
         total_sin_descuento += precio_int 
        if desc == "s":
          precio_final = precio_int * 0.90
        else: 
          precio_final = precio_int

        total_con_descuento += precio_final
        ahorro = total_con_descuento - total_sin_descuento
        promedio = total_con_descuento / cantidad

        print(f"total sin descuento: {total_sin_descuento}")
        print(f"total con descuento {total_con_descuento:.2f}")
        print(f"ahorro total: {ahorro:.2f}")
        print(f"promedio: {promedio:.2f}")


