print("Ejercicio 3 (Alta)")

lun1 = ""
lun2 = ""
lun3 = ""
lun4 = ""

mar1 = ""
mar2 = ""
mar3 = ""

turno_cancelado = 0
turno_mar = 0
turno_lun = 0

operador = input("Ingrese nombre del operador: ").strip()
while not operador.isalpha():
    print("ERROR! Solo ingresar letras")
    operador = input("Ingrese nombre del operador: ").strip()

while True:
    print(""" 
1.Reservar turno 
2.Cancelar turno 
3.Ver agenda del dia
4.Ver resumen general
5.Cerrar sistema
""")

    menu = input("Ingrese una opcion: ").strip()

    while not menu.isdigit():
        print("Error! solo ingrese numeros del 1 al 5")
        menu = input("Ingrese una opcion: ").strip()

    
    if menu == "1":
        nombre = input("Ingrese nombre para agendar turno: ").strip()

        while not nombre.isalpha():
            print("Error, ingrese solo letras")
            nombre = input("Ingrese nombre para agendar turno: ").strip()

        opcion = input("Ingrese 1 para dia lunes o 2 para martes: ").strip()

        while not (opcion == "1" or opcion == "2"):
            print("Error, ingrese solo 1 o 2")
            opcion = input("Ingrese 1 para dia lunes o 2 para martes: ").strip()

        if opcion == "1":

            if lun1 == "":
                lun1 = nombre
                turno_lun += 1
                print("Turno agendado")

            elif lun1 == nombre:
                print("Turno ya reservado")

            elif lun2 == "":
                lun2 = nombre
                turno_lun += 1
                print("Turno agendado")

            elif lun2 == nombre:
                print("Turno ya reservado")

            elif lun3 == "":
                lun3 = nombre
                turno_lun += 1
                print("Turno agendado")

            elif lun3 == nombre:
                print("Turno ya reservado")

            elif lun4 == "":
                lun4 = nombre
                turno_lun += 1
                print("Turno agendado")

            elif lun4 == nombre:
                print("Turno ya reservado")

            else:
                print("No hay turnos para el dia lunes")

        elif opcion == "2":

            if mar1 == "":
                mar1 = nombre
                turno_mar += 1
                print("Turno agendado")

            elif mar1 == nombre:
                print("Turno ya reservado")

            elif mar2 == "":
                mar2 = nombre
                turno_mar += 1
                print("Turno agendado")

            elif mar2 == nombre:
                print("Turno ya reservado")

            elif mar3 == "":
                mar3 = nombre
                turno_mar += 1
                print("Turno agendado")

            elif mar3 == nombre:
                print("Turno ya reservado")

            else:
                print("No hay turnos disponibles para el dia martes")


    elif menu == "2":
        nombre_cancela = input("Ingrese nombre de paciente para cancelar: ").strip()

        if nombre_cancela == lun1 and lun1 != "":
            lun1 = ""
            turno_cancelado += 1
            print("Turno cancelado")

        elif nombre_cancela == lun2 and lun2 != "":
            lun2 = ""
            turno_cancelado += 1
            print("Turno cancelado")

        elif nombre_cancela == lun3 and lun3 != "":
            lun3 = ""
            turno_cancelado += 1
            print("Turno cancelado")

        elif nombre_cancela == lun4 and lun4 != "":
            lun4 = ""
            turno_cancelado += 1
            print("Turno cancelado")

        elif nombre_cancela == mar1 and mar1 != "":
            mar1 = ""
            turno_cancelado += 1
            print("Turno cancelado")

        elif nombre_cancela == mar2 and mar2 != "":
            mar2 = ""
            turno_cancelado += 1
            print("Turno cancelado")

        elif nombre_cancela == mar3 and mar3 != "":
            mar3 = ""
            turno_cancelado += 1
            print("Turno cancelado")

        else:
            print("No se encontro el turno")

    
    elif menu == "3":
        print(f"Turnos lunes: {lun1, lun2, lun3, lun4}")
        print(f"Turnos martes: {mar1, mar2, mar3}")

    
    elif menu == "4":
        print(f"Turnos reservados lunes: {turno_lun}")
        print(f"Turnos reservados martes: {turno_mar}")
        print(f"Turnos cancelados: {turno_cancelado}")

    
    elif menu == "5":
        print("Sesion finalizada")
        break

    else:
        print("Opcion invalida")