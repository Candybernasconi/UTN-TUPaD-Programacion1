print(" Ejercicio 4 — “Escape Room: La Boveda” ")

energia = 100
tiempo = 12
cerraduras_abiertas = 0
alarma = False
codigo_parcial = ""
racha_forzar = 0


agente = input("Ingrese nombre del agente: ").strip()

while not agente.isalpha():
    print("Error! Solo letras")
    agente = input("Ingrese nombre del agente: ").strip()


while energia > 0 and tiempo > 0 and cerraduras_abiertas < 3:

    print("\n--- ESTADO ---")
    print(f"Energia: {energia} | Tiempo: {tiempo} | Cerraduras: {cerraduras_abiertas} | Alarma: {alarma}")

    print("""
1. Forzar cerradura (-20 energia, -2 tiempo)
2. Hackear panel (-10 energia, -3 tiempo)
3. Descansar (+15 energia, -1 tiempo)
""")

    opcion = input("Elegir opcion: ").strip()

    
    while not opcion.isdigit() or not (1 <= int(opcion) <= 3):
        print("Error! Ingrese 1, 2 o 3")
        opcion = input("Elegir opcion: ").strip()

    if opcion == "1":
        energia -= 20
        tiempo -= 2
        racha_forzar += 1

        
        if racha_forzar == 3:
            print("La cerradura se trabó! Se activa la alarma")
            alarma = True

        else:
            
            if energia < 40:
                num = input("Riesgo! Elegir numero (1-3): ")

                while not num.isdigit() or not (1 <= int(num) <= 3):
                    print("Error!")
                    num = input("Elegir numero (1-3): ")

                if num == "3":
                    alarma = True
                    print("Se activó la alarma!")

            
            if not alarma:
                cerraduras_abiertas += 1
                print("Cerradura abierta!")

    elif opcion == "2":
        energia -= 10
        tiempo -= 3
        racha_forzar = 0  

        for i in range(4):
            print(f"Hackeando paso {i+1}/4...")
            codigo_parcial += "A"

        print(f"Codigo parcial: {codigo_parcial}")

        if len(codigo_parcial) >= 8 and cerraduras_abiertas < 3:
            cerraduras_abiertas += 1
            print("Cerradura abierta por hackeo!")

    elif opcion == "3":
        energia += 15
        if energia > 100:
            energia = 100

        tiempo -= 1

        if alarma:
            energia -= 10
            print("La alarma consume energia!")

        racha_forzar = 0  

    
    if alarma and tiempo <= 3 and cerraduras_abiertas < 3:
        print("Sistema bloqueado por alarma!")
        break



if cerraduras_abiertas == 3:
    print("VICTORIA! Abriste la booveda")
elif energia <= 0 or tiempo <= 0:
    print("DERROTA! Sin energia o tiempo")
else:
    print("DERROTA POR BLOQUEO")  
    
