
print("Ejercicio 2 — “Acceso al Campus y Menú Seguros”")
usuario = "alumno"                                            
clave = "python123"

intentos = 0 
max_intentos = 3

while intentos  < max_intentos :
 usuario_correc = input("ingrese su usuario  : ")
 clave_correc = input("ingrese su clave : ")                        #validacion
 if usuario_correc == usuario and clave_correc == clave:
       print("ACCESO PERMITIDO")
       break

 else:
      intentos  += 1
      print("ERROR! Credencial ivalida")                                #intentoslimitados

      if intentos == max_intentos:
        print("Acceso bloqueado")
                  
 
if usuario == usuario_correc and clave == clave_correc:
        
         opcion = ""

         while opcion != "4":
          print("MENU")
          print("Opcion 1 para ver el ESTADO DE INSCRIPCION")                            #VALIDACION MENU
          print("Opcion 2 para CAMBIAR CLAVE" )
          print("Opcion 3 MENSAJE MOTIVACIONAL")
          print("Opcion 4 SALIR")
       
          opcion = input("Seleccione una OPCION de 1-4: ")
 
          while not opcion.isdigit() or int(opcion)< 1 or int(opcion) > 4:                #VALIDACION DE NUMEROS
               opcion = input("ERROR! ingrrese una opcion de 1-4: ")
            
          if opcion == "1":
            print("inscripto")                                                               

          elif opcion == "2":                                                       #CAMBIAR CLAVE
               nueva_clave = input("ingrese una nueva clave: ")

               while len(nueva_clave) < 6:
                nueva_clave = input("ERROR! la contraseña debe tener 6 o mas caractres, REINTENTAR : ")
                print("CONTRASEÑA VALIDA")

               confirmar = input("repita la contraseña: ")
               print("contraseña creada exitosamente")
               while nueva_clave != confirmar:
                print("CONTRASEÑA INVALIDA")
               print("contraseña creada exitosamente")

          elif opcion == "3":
                 print("INTENTAR ES TRIUNFAR")



      